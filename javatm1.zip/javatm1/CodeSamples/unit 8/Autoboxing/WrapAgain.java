
import java.util.*;
class WrapAgain{
public static void main(String arg[]){

ArrayList myList =new ArrayList();

int i=5;

Integer iob = new Integer(i);

myList.add(0,iob);

Integer myiob = (Integer)myList.get(0);
int j = myiob .intValue();

System.out.println("value of j :"+j);

}



}