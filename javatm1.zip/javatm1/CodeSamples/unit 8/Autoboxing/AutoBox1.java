class AutoBox1{

static int myMethod(Integer v){

return v;//auto unboxing to int


}

public static void main(String arg []){

Integer iob = myMethod(100);
System.out.println(iob);

}



}