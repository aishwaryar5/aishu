class AutoBox2{
public static void main(String arg[]){

Integer iob1,iob2;

int i;
iob1=100;
System.out.println("original value of iob1: "+iob1);
++iob1;
System.out.println("After ++iob1: "+iob1);

iob2 = iob1+(iob1/3);

System.out.println("iob2 after expression :"+iob2);

       i= iob1 +(iob1/3);

System.out.println("i after expresion :"+ i);

}











}