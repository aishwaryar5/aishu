class AutoBox{


public static void main(String arg[]){

Integer iob = 100;

int i=iob;


System.out.println("value "+i+" "+iob);

}




}