class Wrap{

public static void main(String arg[]){
int i=100;

Integer iob = new Integer(i);

int j = iob.intValue();

System.out.println("j value :"+j+" "+iob);

}

}