class AutoBox3{
public static void main(String arg[]){

Integer iob =100;
Double dob=98.6;

dob=dob+iob;

System.out.println("dob after conversion :"+dob);



}









}