import java.util.*;
class SetTest{

public static void main(String arg[]){

Set s = new HashSet();
boolean[] ba = new boolean[5];
ba[0] = s.add("a");
ba[1] = s.add(new Integer(42));
ba[2] = s.add("b");
ba[3] = s.add("a");
ba[4] = s.add(new Object());

for(int x=0; x<ba.length; x++){

System.out.println(ba[x]+" ");

}

for(Object o: s)
System.out.println(o + " ");

}




}