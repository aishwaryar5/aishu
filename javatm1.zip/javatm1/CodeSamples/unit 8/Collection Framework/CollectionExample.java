import java.util.*;
class CollectionExample{

public static void main(String arg[]){

List<String> test = new ArrayList<String>();
String s="hi";
test.add("String");
test.add(s);
test.add(s+s);
System.out.println(test.size());
System.out.println(test.contains(42));
System.out.println(test.contains("hihi"));
System.out.println(test.remove("hi"));
System.out.println(test.size());

}


}