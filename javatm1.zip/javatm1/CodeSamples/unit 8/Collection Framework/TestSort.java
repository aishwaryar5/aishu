import java.util.*;
class TestSort{
public static void main(String a[]){
ArrayList <String> stuff = new ArrayList<String> ();
stuff.add("Chennai");
stuff.add("Madurai");
stuff.add("Bangalore");
stuff.add("Tiruchi");

System.out.println("unsorted :"+stuff);
Collections.sort(stuff);
System.out.println("sorted :"+stuff);

}

}
