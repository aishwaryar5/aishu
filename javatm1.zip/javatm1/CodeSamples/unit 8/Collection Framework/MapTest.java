import java.util.*;
class MapTest
{
public static void main(String arg[])
{
Map<Object, Dog>m = new HashMap<Object, Dog>();
m.put("K1",new Dog("Rosy"));
m.put("K2",new Dog("Jaisy"));
m.put("K3",new Dog("Musi"));
m.put("K4","I am not dog");
System.out.println("Name of the dog "+ m.get("K1").getName());
System.out.println("Name of the dog "+ m.get("K2").getName());
System.out.println("Name of the dog "+ m.get("K3").getName());



}
}
class Dog{
public Dog(String n){
name = n;
//System.out.println(name);
}
String name;

public String getName(){
return name;

}


}