
import java.util.*;
class GenericsExample{
public static void main(String arg[]){

List <Dog> myList = new ArrayList<Dog>();


//myList.add("Joseph");


myList.add(new Dog("july"));


//String s= myList.get(0);

Dog d = myList.get(0);


//System.out.println("value of s "+s);
System.out.println("name of dog "+d.name);



}


}