class Dog{

private name;

public String getName(){

return this.name;


}


public void setName(String name){

this.name = name

}


}