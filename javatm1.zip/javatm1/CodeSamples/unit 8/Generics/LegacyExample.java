import java.util.*;
class LegacyExample{
public static void main(String arg[]){

List myList =new ArrayList();
myList.add("Martin");
myList.add(new Dog("July"));
myList.add(new Integer(42));




String s= (String)myList.get(0);
System.out.println("value of s :"+s);



Dog d = (Dog)myList.get(1);
String s1 = (String)myList.get(1);

System.out.println("name of dog:" + d.name);



}





}