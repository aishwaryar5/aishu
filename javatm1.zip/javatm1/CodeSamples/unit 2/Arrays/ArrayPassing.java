package arrays;

public class ArrayPassing {

	public static void printArray(int[] array) {
		  for (int i = 0; i < array.length; i++) {
		    System.out.print(array[i] + " ");
		  }
		}
	
	public static void main(String[] args) {
		
		int[] sample = {5,7,2,56,30,14,9,10};
		printArray(sample);
	}
}
