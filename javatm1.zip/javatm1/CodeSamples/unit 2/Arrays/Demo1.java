package arrays;

public class Demo1 {

	//Basic structure: dataType[] arrayRefVar = new dataType[arraySize];
	// eg: double[] myList = new double[10];
	//Alternate : dataType[] arrayRefVar = {value0, value1, ..., valuek};
	
	   public static void main(String[] args) {
		      double[] myList = {1.9, 2.9, 3.4, 3.5};

		      // Print all the array elements
		      for (int i = 0; i < myList.length; i++) {
		         System.out.println(myList[i] + " ");
		      }
		      
		      // Summing all elements
		      double total = 0;
		      for (int i = 0; i < myList.length; i++) {
		         total = total + myList[i];
		      }
		      System.out.println("Total is " + total);
		      
	   }
	
}
