package arrays;

import java.util.Arrays;

public class ArraysSort {

	public static void main(String[] args) {
		
		int[] table3 = {6,33,27,15,3,18,0,24,30,12,9};
		
		Arrays.sort(table3);
		
		for (int item : table3){
			
			System.out.println(item);
		}
	}
}
