//this code will not compile because we try to access y, outside of its scope.

class Scope{

public static void main(String arg[]){

int x;

x=10;


if(x==10){
int y=15;

}
y=100;
System.out.println("x is"+x );


}






}