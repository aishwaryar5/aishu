//example for automatic type promotion in expression
class Conversion{
public static void main(String arg[]){


byte b=42;
char c=12;
short s=100;
int i=102;
float f=5.65f;
double d=.124;

float result =(f*b)+(i/c)-(f*s);

System.out.println("result: "+result);

}


}
