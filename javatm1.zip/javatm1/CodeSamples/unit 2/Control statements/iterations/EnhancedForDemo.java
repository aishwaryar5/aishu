package loops;

public class EnhancedForDemo {

	public static void main(String args[]){
	      
	      String [] names ={"James", "Larry", "Tom", "Lacy"};
	      
	      for( String item : names ) {
	    	  
	         System.out.println( item );
	         
	      }
	   }

}
