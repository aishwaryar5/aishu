package loops;

/* Code to print from 10 to 19 */
public class ForLoopDemo {

	public static void main(String args[]) {

	      for(int x = 10; x < 20; x = x+1) {
	    	  
	         System.out.println("value of x : " + x );
	         
	      }
	   }

}
