//example for enhanced for loop
class Control{

public static void main(String arg[]){


int num[] = {1,2,3,4,5};
int sum  =0;

for (int x:num){

sum +=x;
}

System.out.println("Sum :"+ sum);

}


}