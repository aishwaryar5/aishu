package loops;

/* Code to print from 10 to 19 */
public class WhileLoopDemo {

	public static void main(String args[]) {
	      int x = 10;

	      while( x < 20 ) {
	         System.out.println("value of x : " + x );
	         x++;
	         
	      }
	   }
}
