package loops;

public class DoWhileLoopDemo {

	public static void main(String args[]){
	      int x = 10;

	      do{
	    	  
	         System.out.println("value of x : " + x );
	         x++;
	         
	      }while( x < 20 );
	      
	   }
}