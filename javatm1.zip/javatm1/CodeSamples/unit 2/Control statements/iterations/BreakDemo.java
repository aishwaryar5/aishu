package loops;


/*Execution BREAKS when reached a break point to save execution time */
public class BreakDemo {

	public static void main(String args[]) {
	      int [] numbers = {10, 20, 30, 40, 50};

	      for(int x = 10; x < 60; x = x + 10) {
	    	  
	         if( x == 30 ) {
	        	 break;
	         }
	         
	         System.out.println( x );
	         
	      }
	   }

}
