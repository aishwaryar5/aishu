package decisions;


public class IfElseDemo {
	
	// This demonstrates the If...Else
	public static void main(String args[]){
	      int x = 30;

	      if( x < 20 ){
	         System.out.print("This is if statement");
	      }else{
	         System.out.print("This is else statement");
	      }
	   }

	// This demonstrates the If...Else If... Else
	/*public static void main(String args[]){
	      int x = 30;

	      if( x == 10 ){
	         System.out.print("Value of X is 10");
	      }else if( x == 20 ){
	         System.out.print("Value of X is 20");
	      }else if( x == 30 ){
	         System.out.print("Value of X is 30");
	      }else{
	         System.out.print("Value of X does not exist!");
	      }
	   }*/

}
