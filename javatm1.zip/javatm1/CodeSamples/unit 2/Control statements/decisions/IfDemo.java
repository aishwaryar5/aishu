package decisions;

public class IfDemo {

	public static void main(String args[]){
	      int x = 10;

	      if( x < 20 ){
	         System.out.print("This is a true statement");
	      }
	   }

}
