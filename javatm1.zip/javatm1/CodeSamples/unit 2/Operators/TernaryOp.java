package operators;

public class TernaryOp {

	
	// Structure of a Ternary Operator:
	// variable x = (expression) ? value if true : value if false;
	
	public static void main(String args[]){
	      int a, b;
	      a = 10;
	      
	      /* Condition 1 */
	      b = (a == 1) ? 20: 30;
	      System.out.println( "Value of b is : " +  b );

	      /* Condition 2 */
	      b = (a == 10) ? 20: 30;
	      System.out.println( "Value of b is : " + b );
	   }
}
