//example for short circuit And operator
class Operators{

public static void main(String arg[]){

int denom=1;

int num= 5;

if((denom !=0) && (num/denom<10))
System.out.println("it will also print");

System.out.println("it will  print");

//expression1?expression2:expression3

}



}