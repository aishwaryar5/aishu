class Uncaught{
public static void main(String K[]){

int d;
int a;

try{

d=0;
a= 42/d;
System.out.println("�fter division");
}
catch(NullPointerException e){
System.out.println("NullPointer :"+ e);

}

catch(ArithmeticException e){
System.out.println("Division by zero :"+ e);

}


System.out.println("After catch");
}

}

