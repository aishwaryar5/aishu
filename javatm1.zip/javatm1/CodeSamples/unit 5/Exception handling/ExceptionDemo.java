class ExceptionDemo{
static int d=0;
static int k;
static void compute(int withrawalAmount) throws InsufficientBalanceException{

System.out.println("called compute("+ withrawalAmount+ ")");


if (withrawalAmount>1000)
throw new InsufficientBalanceException(withrawalAmount);
else
k=withrawalAmount/d;
System.out.println("Normal Exit");




}

public static void main(String arg[]){

try{

compute(1500);
compute(20);

}
catch(InsufficientBalanceException e){
System.out.println("caught :"+ e);
}
finally{
System.out.println("i print always");

}


}




}