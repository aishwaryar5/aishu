class InsufficientBalanceException extends Exception{

private int detail;

InsufficientBalanceException (int a){
detail=a;

}
public String toString(){

return "insufficient balance in your account";

}

}



