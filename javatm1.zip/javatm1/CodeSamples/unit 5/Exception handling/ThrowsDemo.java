class ThrowsDemo{
static void anotherprog()throws IllegalAccessException {

System.out.println("inside anotherprog");

throw new IllegalAccessException("demo");


}

public static void main(String arg[]){
try{

anotherprog();

}


catch (IllegalAccessException e){


System.out.println("caught :"+ e);
}

}


}