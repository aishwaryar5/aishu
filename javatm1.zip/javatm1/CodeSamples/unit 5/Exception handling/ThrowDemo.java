class ThrowDemo{
Box b ;

 void demoprog(){

try{
b= new Box(7,8,9);
System.out.println("value of b :"+b);
if(b!=null)
b.volume();

}
catch(NullPointerException e){
System.out.println("caught inside demoprog");

throw e;
}

          

}

public static void main(String arg[]){
ThrowDemo th = new ThrowDemo();
try{
th.demoprog();

}
catch(NullPointerException e){

System.out.println("recaught :"+ e);
}

}



}