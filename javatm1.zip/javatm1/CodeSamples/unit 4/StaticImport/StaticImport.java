import static java.lang.Integer.MAX_VALUE;
import static java.lang.Integer.MIN_VALUE;



class StaticImport{

public static void main(String arg[]){


System.out.println("Maximum value of int variable in Java without static import "+ Integer.MAX_VALUE);
System.out.println("Minimum value of int variable in Java without static import "+ Integer.MIN_VALUE);

System.out.println("Maximum value of int variable in Java with static import "+ MAX_VALUE);
System.out.println("Minimum value of int variable in Java with static import "+ MIN_VALUE);



}








}