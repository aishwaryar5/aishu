package mypack;

class Balance{

String name;
double bal;

Balance(String n, double d){

name=n;
bal=d;

}

String getName(){

return name;

}

double getBalance(){
return bal;
}
}
class AccountBalance{


public static void main(String k[]){

Balance b = new Balance("Ram",2000);
System.out.println("Name of the account holder: " +b.getName());
System.out.println("Balance: " +b.getBalance());


}

}