import java.io.*;
public class BufferedStreamExample {
	
	
	public static void main(String a[]){
		
		
		File file = new File("c:/samples/bufferfile.txt");
		
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		
		try{
			
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
			
			while(dis.available()!=0){
				
				System.out.println(dis.readLine());
				
				
			}
			
			
		}catch(Exception e){
			
					
			
		}finally{
			
			try{
				fis.close();
				bis.close();
				dis.close();
				
			}catch(Exception e){
				
				
			}
					
			
			
			
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	
	

}
