import java.io.*;


public class ByteStreamExample {
	
	public static void main(String a[]){
		
		
		FileInputStream in = null;
		FileOutputStream out = null;
		
		
		try{
			
			in = new FileInputStream("c:/samples/test.txt");
			out = new FileOutputStream("c:/samples/output.txt");
			
			int c;
			
			while((c=in.read())!= -1){
				
				out.write(c);
				
				
			}
			
			
			
			
			
		}catch(Exception e){
			
		}
		
		finally{
			if(in!=null){
				try{
				in.close();
				}
				catch(Exception e){}
			}
			if(out!=null){
				try{
				out.close();
				}
				catch(Exception e){}
			}
			
			
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
