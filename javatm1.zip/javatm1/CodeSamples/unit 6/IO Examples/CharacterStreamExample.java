import java.io.*;
public class CharacterStreamExample {
	
	public static void main(String a[]){
		
		FileReader fr = null;
		FileWriter fw = null;
		
		try{
			
			fr = new FileReader("c:/samples/char.txt");
			fw = new FileWriter("c:/samples/charoutput.txt");
			
			int c;
			
			while((c=fr.read())!= -1){
				
				fw.write(c);
				
				
			}
			
		}catch(Exception e){
			
			
		}finally{
			if(fr!= null){
				try{
					fr.close();
					
					
				}catch(Exception e){
					
				}
				
				
			}
			if(fw!= null){
				try{
					fw.close();
					
					
				}catch(Exception e){
					
				}
				
				
			}
			
			
		}
		
		
		
		
		
		
		
		
			
		
	}
	
	

}
