class NewThread implements Runnable{

Thread t;


NewThread(String name){
//create a new second thread
t=new Thread(this,name);
System.out.println("Child thread"+ name);
t.start();

}

//entry point of second thread

public void run(){
try{
for(int i=5;i>0; i--){

System.out.println("child thread :"+i);
Thread.sleep(500);
}
}catch(InterruptedException e){
System.out.println("child interrupted");

}
System.out.println("child exiting ");

}

}

class ThreadDemo{
public static void main(String arg[]){
NewThread ob1 = new NewThread("one");//creating a new thread
NewThread ob2 = new NewThread("two");
NewThread ob3 = new NewThread("three"); 

System.out.println("thread one is alive :"+ ob1.t.isAlive());
System.out.println("thread two is alive :" +ob2.t.isAlive());
System.out.println("thread three is alive :"+ ob3.t.isAlive());


try{

for(int i=5; i>0; i--){
System.out.println("main thread");
System.out.println("thread one is alive :"+ ob1.t.isAlive());
System.out.println("thread two is alive :"+ ob2.t.isAlive());
System.out.println("thread three is alive :"+ ob3.t.isAlive());
Thread.sleep(1000);

}

}catch(InterruptedException e){
System.out.println("main thread interrupted");
}

}



}




