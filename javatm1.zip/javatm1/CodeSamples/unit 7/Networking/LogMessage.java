
interface LogMessage {
  public void log(String msg);
}


