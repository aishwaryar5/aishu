package inheritence;

class Animal{
	
}

class Mammal extends Animal{
}

class Reptile extends Animal{
}

class Dog extends Mammal{

}

public class InheritDemoAnimal {

	public static void main(String args[]){

	      Animal dogfamily = new Animal();
	      Mammal labrador = new Mammal();
	      Dog simba = new Dog();

	      System.out.println(labrador instanceof Animal);
	      System.out.println(simba instanceof Mammal);
	      System.out.println(simba instanceof Animal);
	   }
}
