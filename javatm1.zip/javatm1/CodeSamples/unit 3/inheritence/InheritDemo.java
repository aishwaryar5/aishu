package inheritence;

/* Basic structure:
 * 
class Super{
.....
.....
}

class Sub extends Super{
.....
.....

}
*/

class Calculation{ 
	   int z;
		
	   public void add(int x, int y){
	      
	      System.out.println("The sum of the given numbers:"+(x+y));
	   }
		
	   public void subtract(int x,int y){

		   System.out.println("The difference between the given numbers:"+(Math.abs(x-y)));
	   }
	   
}

class My_Calculation extends Calculation{    
	  
	   public void multiply(int x, int y){
	     
	      System.out.println("The product of the given numbers:"+(x*y));
	   }
		
}
	
public class InheritDemo {
	
	public static void main(String args[]){
	      int a = 20, b = 10;
	      My_Calculation demo = new My_Calculation();
	      demo.add(a, b);
	      demo.subtract(a, b);
	      demo.multiply(a, b);      
	   }
}
