package classandobject;

public class PConstructor {

	    int id;
	    String name;
	    
	    PConstructor(int i,String n){
	    id = i;
	    name = n;
	    }
	    void display(){System.out.println(id+" "+name);}
	 
	    public static void main(String args[]){
	    	PConstructor s1 = new PConstructor(111,"Karan");
	    	PConstructor s2 = new PConstructor(222,"Aryan");
	    s1.display();
	    s2.display();
	  }
}
