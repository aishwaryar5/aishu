package classandobject;

public class Constructor {


	/* 2 imp characteristics:
	 * 	 1. No return type
	 *   2. Name is same as the classname
	 */
		public Constructor()
		{
			
			System.out.println("Constructor is created! ");
		}

		public static void main(String args[]){
			
			Constructor c = new Constructor();
		}
}
