 class Bob{
int shoesize;
String nickName;

Bob(String nickName,int shoesize){

this.shoesize = shoesize;
this.nickName=nickName;


}

public String toString(){

	return "I  am Bob my NickName is " +nickName;

}

}

public class BobTest{

public static void main(String arg[]){
Bob f = new Bob("GoBobGo",19);

System.out.println("bob "+ f );

}



}