public class EqualsTest{

public static void main(String arg[]){

Moof one = new Moof(8);
Moof two = new Moof(9);
String s1 = new String("My name is Ram");
String s2 = new String("My name is Ram");




if (s1.equals(s2)){

System.out.println("They are equal");

}






}

}
class Moof{
private int moofValue;

Moof(int val){
moofValue = val;

}

public int getMoofValue(){
return moofValue;

}

public boolean equals(Object o){

if((o instanceof Moof)&& (((Moof)o).getMoofValue()==this.getMoofValue()) ){

return true;


}else{
return false;

}

}



}