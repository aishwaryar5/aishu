
class Box{

public double width;
private double height;
private double depth;




Box(){

}

Box(double width, double height, double depth){
this.width=width;
this.height=height;
this.depth=depth;

}

Box(double length){
this.width=length;
this.height=length;
this.depth=length;


}

void volume(){

System.out.println("inside volume method  Volume : " + width *height *depth);

}

}

class BoxWeight extends Box{
double weight ;

BoxWeight(double width, double height, double depth, double weight){

super(width,height,depth);
this.weight  = weight ;


}

void volume(){

super.volume();
System.out.println("weight :"+weight);

}

}



class BoxDemo1{


public static void main(String s[]){

BoxWeight bw=new BoxWeight (1,2,3,4);

bw.volume();


}
}