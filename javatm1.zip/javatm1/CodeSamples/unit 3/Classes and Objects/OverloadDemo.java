//example for method overloading
class Overload{

void test(){

System.out.println("no parameters");

}


void test(int i){

System.out.println("i "+i);

}


void test(int i,int k){

System.out.println("i and k "+i+" "+ k);

}

}

class OverloadDemo{
public static void main(String a[]){
Overload ob = new Overload();
ob.test();
ob.test(10);
ob.test(10,20);
}
}