class A{

int i;
void showi(){
System.out.println("i :"+ i);


}

}


class B extends A{
int j;
int k;
void showj(){
System.out.println("j :"+ j);

}


void sum(){
System.out.println("i inside sum :"+i);
System.out.println("j inside sum :"+j);

k=i+j;
System.out.println("sum :"+ k);

}
}
class InheritDemo{
public static void main(String s[]){

//A a = new A();
//a.i=4;
//a.showi();
B b= new B();
b.i=4;
b.j=3;
b.showj();
b.sum();

}



}