//example for runtime polimorphism
class R{

 void callme(){
System.out.println("inside R");

}
}


abstract class A extends R{

void somemethod(){
System.out.println("inside A");
}
}

class B extends R{

void callme(){
System.out.println("inside B");


}

}


class Dispatch{

public static void main(String k[]){

R r = new R();
r.callme();

A a = new A();
B b = new B();

r = a;
r.callme();

r =b;
r.callme();

}


}