package Polymorphism;


/* Method overriding example */

class Human {
		
		public void eat()
		   {
		      System.out.println("Human is eating");
		   }
}
	
class Boy extends Human {
	
		public void eat(){
		      System.out.println("Aaron is eating");
		}
}	

public class MethodOverriding {
	
		   public static void main( String args[]) {
			   
		      Boy aaron = new Boy();
		      aaron.eat();
		      
		   }
	
}
